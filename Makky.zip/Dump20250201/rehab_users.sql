-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: rehab
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','professional','participant') NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `gender` enum('Male','Female','Other') DEFAULT NULL,
  `profession` varchar(255) DEFAULT NULL,
  `national_id` varchar(20) DEFAULT NULL,
  `address` text,
  `rehab_reason` text,
  `verified` tinyint(1) DEFAULT '0',
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_token_expires` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `national_id` (`national_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Admin','admin','admin@r.com','$2a$12$CbacWnejN6eOiLhXM3c3UeCtH47NUADJXXw0W64luHyS0jQ87w612','admin','2024-12-01 22:04:30','2025-01-30 17:40:37',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL),(2,'makky','makky','makky@r.com','$2a$10$MofCv5fWKfPhXiEzVQrDB.eEHPjNxkzSAhnx/dYWlQCE8emYYQNVa','participant','2024-12-16 10:57:49','2025-01-31 15:41:27','TC','TC','Male',NULL,'1222222222222222','kigali','Weed',1,NULL,NULL),(3,'benjamin','benja','benja@gmail.com','$2a$10$X9hZWYizAQOLG9hNyJHF7up8gfQndkyIehVh7UaH9sNcMk/1HWfnO','professional','2024-12-16 13:51:08','2025-01-30 18:22:17',NULL,NULL,'Male','Doctor',NULL,'',NULL,1,NULL,NULL),(4,'ndekestro','ndekestro','turachretien@gmail.com','$2a$10$O.hxUjKUpYqn2/rhhPITgOrmcIbym9fouL68RsJ0GkwjtyQT.Hx.a','participant','2024-12-16 19:01:10','2025-01-30 18:13:15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL),(7,'Turashimye Chretien','user1','turashimyechretien@gmail.com','$2a$10$i6DHSVhESxrRoMxPa92YoO0GT/0CseFDblWRPPvh4K4Wm5Tf4EFU.','participant','2025-01-30 18:34:46','2025-01-30 18:55:54',NULL,NULL,NULL,NULL,'122999999999','Kigali','no',0,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-01 17:08:42
